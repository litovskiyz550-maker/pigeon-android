import { useState } from "react";
import { LoadingScreen } from "./components/LoadingScreen";
import { TeamScreen } from "./components/TeamScreen";
import { RussiaRadar } from "./components/RussiaRadar";
import { CityView } from "./components/CityView";
import type { City } from "./data/cities";

type Screen = "loading" | "team" | "radar" | "city";

export default function App() {
  const [screen, setScreen] = useState<Screen>("loading");
  const [city, setCity] = useState<City | null>(null);

  return (
    <div className="h-full w-full">
      {screen === "loading" && <LoadingScreen onDone={() => setScreen("team")} />}
      {screen === "team" && <TeamScreen onRadar={() => setScreen("radar")} />}
      {screen === "radar" && (
        <RussiaRadar
          onBack={() => setScreen("team")}
          onSelect={(c) => {
            setCity(c);
            setScreen("city");
          }}
        />
      )}
      {screen === "city" && city && <CityView city={city} onBack={() => setScreen("radar")} />}
    </div>
  );
}
