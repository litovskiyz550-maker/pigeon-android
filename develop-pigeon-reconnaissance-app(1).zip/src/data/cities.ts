export interface City {
  id: string;
  name: string;
  region: string;
  lat: number;
  lon: number;
}

// Реальные координаты центров городов России
export const CITIES: City[] = [
  { id: "moscow", name: "Москва", region: "Центральный ФО", lat: 55.7558, lon: 37.6173 },
  { id: "spb", name: "Санкт-Петербург", region: "Северо-Западный ФО", lat: 59.9343, lon: 30.3351 },
  { id: "voronezh", name: "Воронеж", region: "Центральный ФО", lat: 51.672, lon: 39.1843 },
  { id: "omsk", name: "Омск", region: "Сибирский ФО", lat: 54.9885, lon: 73.3242 },
  { id: "novosibirsk", name: "Новосибирск", region: "Сибирский ФО", lat: 55.0084, lon: 82.9357 },
  { id: "ekb", name: "Екатеринбург", region: "Уральский ФО", lat: 56.8389, lon: 60.6057 },
  { id: "kazan", name: "Казань", region: "Приволжский ФО", lat: 55.7887, lon: 49.1221 },
  { id: "samara", name: "Самара", region: "Приволжский ФО", lat: 53.1959, lon: 50.1002 },
  { id: "rostov", name: "Ростов-на-Дону", region: "Южный ФО", lat: 47.2357, lon: 39.7015 },
  { id: "krasnodar", name: "Краснодар", region: "Южный ФО", lat: 45.0355, lon: 38.9753 },
  { id: "volgograd", name: "Волгоград", region: "Южный ФО", lat: 48.708, lon: 44.5133 },
  { id: "krasnoyarsk", name: "Красноярск", region: "Сибирский ФО", lat: 56.0153, lon: 92.8932 },
];

export interface Scout {
  id: number;
  callsign: string;
  role: string;
  color: string;
  speed: number;
  vision: number;
  stamina: number;
}

export const SCOUTS: Scout[] = [
  { id: 1, callsign: "Сизарь", role: "Командир стаи", color: "#9aa7bd", speed: 82, vision: 90, stamina: 88 },
  { id: 2, callsign: "Гром", role: "Дальний дозор", color: "#7f8da6", speed: 91, vision: 78, stamina: 94 },
  { id: 3, callsign: "Дымок", role: "Ночной разведчик", color: "#6d7a92", speed: 76, vision: 96, stamina: 80 },
  { id: 4, callsign: "Буран", role: "Скоростной связной", color: "#b4bfd1", speed: 97, vision: 72, stamina: 85 },
  { id: 5, callsign: "Радар", role: "Наблюдатель", color: "#8794ad", speed: 70, vision: 99, stamina: 83 },
  { id: 6, callsign: "Тень", role: "Скрытный дозорный", color: "#59657c", speed: 84, vision: 86, stamina: 90 },
];

export const POST_NAMES = ["Север", "Северо-восток", "Юго-восток", "Юг", "Юго-запад", "Северо-запад"];
// азимут каждого поста (градусы от севера по часовой)
export const POST_BEARINGS = [0, 60, 120, 180, 240, 300];

export const KM_LAT = 111.32;
export function kmToLatLon(city: City, xKm: number, yKm: number): [number, number] {
  const lat = city.lat + yKm / KM_LAT;
  const lon = city.lon + xKm / (KM_LAT * Math.cos((city.lat * Math.PI) / 180));
  return [lat, lon];
}
