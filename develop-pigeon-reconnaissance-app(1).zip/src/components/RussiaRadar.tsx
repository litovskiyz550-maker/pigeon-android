import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { CITIES, type City } from "../data/cities";

export function RussiaRadar({ onSelect, onBack }: { onSelect: (c: City) => void; onBack: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const selectRef = useRef(onSelect);
  selectRef.current = onSelect;

  useEffect(() => {
    if (!ref.current) return;
    const map = L.map(ref.current, {
      zoomControl: false,
      attributionControl: true,
      minZoom: 2,
      maxZoom: 8,
      zoomSnap: 0.25,
    });
    L.control.zoom({ position: "bottomright" }).addTo(map);
    L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
      attribution: "© OpenStreetMap © CARTO",
      subdomains: "abcd",
    }).addTo(map);
    map.fitBounds([[43, 28], [62, 100]], { padding: [10, 10] });

    CITIES.forEach((c) => {
      const icon = L.divIcon({
        className: "city-marker",
        html: `<div class="city-btn"><span class="city-dot"></span><span class="city-label">${c.name}</span></div>`,
        iconSize: [0, 0],
      });
      L.marker([c.lat, c.lon], { icon, keyboard: true, title: c.name }).on("click", () => selectRef.current(c)).addTo(map);
    });

    return () => {
      map.remove();
    };
  }, []);

  return (
    <div className="relative h-full w-full bg-[#03120a]">
      <div ref={ref} className="radar-map absolute inset-0 vignette scanlines" />

      {/* круговые риски радара */}
      <div className="pointer-events-none absolute inset-0 z-[450] flex items-center justify-center">
        <div className="relative" style={{ width: "min(95vw,95vh)", height: "min(95vw,95vh)" }}>
          {[1, 0.75, 0.5, 0.25].map((k) => (
            <div
              key={k}
              className="absolute rounded-full border border-emerald-400/20"
              style={{ inset: `${((1 - k) / 2) * 100}%` }}
            />
          ))}
          <div className="absolute left-1/2 top-0 h-full w-px bg-emerald-400/15" />
          <div className="absolute top-1/2 left-0 w-full h-px bg-emerald-400/15" />
          <div className="radar-sweep absolute inset-0" />
        </div>
      </div>

      {/* шапка */}
      <div className="absolute inset-x-0 top-0 z-[600] flex items-center justify-between gap-2 bg-gradient-to-b from-black/80 to-transparent px-3 pt-3 pb-8">
        <button
          onClick={onBack}
          className="rounded-lg border border-emerald-500/40 bg-black/60 px-3 py-1.5 text-sm text-emerald-200 active:scale-95"
        >
          ← Назад
        </button>
        <div className="text-right">
          <p className="font-mono-r text-xs tracking-[0.25em] text-emerald-400">РАДАР · РОССИЯ</p>
          <p className="text-[11px] text-emerald-200/70">Выберите город для наблюдения</p>
        </div>
      </div>

      {/* список городов */}
      <div className="absolute inset-x-0 bottom-0 z-[600] bg-gradient-to-t from-black/90 via-black/60 to-transparent px-3 pb-3 pt-10">
        <div className="mx-auto flex max-w-3xl flex-wrap justify-center gap-1.5 pr-14">
          {CITIES.map((c) => (
            <button
              key={c.id}
              onClick={() => onSelect(c)}
              className="rounded-full border border-emerald-500/50 bg-emerald-950/80 px-3 py-1.5 text-xs font-semibold text-emerald-100 active:scale-95 hover:bg-emerald-500 hover:text-emerald-950 transition"
            >
              {c.name}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
