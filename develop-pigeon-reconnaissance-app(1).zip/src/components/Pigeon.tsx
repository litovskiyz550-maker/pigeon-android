interface PigeonProps {
  size?: number;
  color?: string;
  flap?: boolean;
  className?: string;
  flip?: boolean;
}

export function Pigeon({ size = 120, color = "#9aa7bd", flap = true, className = "", flip = false }: PigeonProps) {
  return (
    <svg
      width={size}
      height={size * 0.75}
      viewBox="0 0 120 90"
      className={className}
      style={flip ? { transform: "scaleX(-1)" } : undefined}
      aria-hidden="true"
    >
      {/* хвост */}
      <polygon points="34,46 4,38 8,50 4,62 34,56" fill="#4b566b" />
      {/* дальнее крыло */}
      <path
        d="M44 42 Q56 8 90 28 Q70 46 44 50 Z"
        fill="#4b566b"
        className={flap ? "pigeon-wing-back" : ""}
        style={{ transformOrigin: "60px 46px" }}
      />
      {/* тело */}
      <ellipse cx="60" cy="50" rx="32" ry="18" fill={color} />
      <ellipse cx="58" cy="58" rx="22" ry="8" fill="#ffffff" opacity="0.18" />
      {/* шея */}
      <path d="M78 46 Q92 46 92 34 L100 40 Q96 56 80 58 Z" fill={color} />
      {/* переливающееся пятно */}
      <ellipse cx="86" cy="43" rx="8" ry="7" fill="#3fb59a" opacity="0.75" />
      <ellipse cx="88" cy="46" rx="5" ry="4" fill="#9b5de5" opacity="0.5" />
      {/* голова */}
      <circle cx="94" cy="31" r="12" fill={color} />
      {/* клюв */}
      <polygon points="104,29 118,34 104,38" fill="#e9c46a" />
      <circle cx="112" cy="33" r="1.4" fill="#7a5c14" />
      {/* глаз */}
      <circle cx="97" cy="29" r="3.2" fill="#ff7b2e" />
      <circle cx="97.6" cy="28.6" r="1.4" fill="#111" />
      {/* ближнее крыло */}
      <g className={flap ? "pigeon-wing" : ""} style={{ transformOrigin: "60px 46px" }}>
        <path d="M36 44 Q58 10 90 40 Q66 62 36 52 Z" fill="#5f6c84" />
        <path d="M46 44 Q62 26 82 40" stroke="#2e3646" strokeWidth="2.5" fill="none" strokeLinecap="round" />
        <path d="M44 49 Q62 38 80 45" stroke="#2e3646" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      </g>
      {/* лапки */}
      <path d="M60 66 L58 78 M66 66 L66 78" stroke="#d1495b" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}
