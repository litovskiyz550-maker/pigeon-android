import { useEffect, useRef, useState } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { Pigeon } from "./Pigeon";
import { POST_BEARINGS, POST_NAMES, SCOUTS, kmToLatLon, type City } from "../data/cities";

interface LogEntry {
  id: number;
  time: string;
  level: "info" | "alert" | "ok";
  text: string;
}

const POST_RADIUS_KM = 6;
const FLIGHT_MS = 4500;
const DETECT_KM = 4.5;
const KILL_KM = 1.4;

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

export function CityView({ city, onBack }: { city: City; onBack: () => void }) {
  const mapEl = useRef<HTMLDivElement>(null);
  const sweepEl = useRef<HTMLDivElement>(null);
  const audioRef = useRef<AudioContext | null>(null);
  const mutedRef = useRef(false);

  const [log, setLog] = useState<LogEntry[]>([]);
  const [birdsOnPost, setBirdsOnPost] = useState(0);
  const [detected, setDetected] = useState(0);
  const [destroyed, setDestroyed] = useState(0);
  const [active, setActive] = useState(0);
  const [muted, setMuted] = useState(false);

  mutedRef.current = muted;

  useEffect(() => {
    if (!mapEl.current) return;
    setLog([]);
    setBirdsOnPost(0);
    setDetected(0);
    setDestroyed(0);
    setActive(0);

    let logId = 0;
    const addLog = (level: LogEntry["level"], text: string) => {
      const time = new Date().toLocaleTimeString("ru-RU");
      setLog((prev) => [{ id: ++logId, time, level, text }, ...prev].slice(0, 80));
    };

    const beep = (freq: number, times = 1) => {
      if (mutedRef.current) return;
      try {
        if (!audioRef.current) {
          const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
          audioRef.current = new Ctx();
        }
        const ctx = audioRef.current;
        if (ctx.state === "suspended") void ctx.resume();
        for (let i = 0; i < times; i++) {
          const o = ctx.createOscillator();
          const g = ctx.createGain();
          o.type = "square";
          o.frequency.value = freq;
          g.gain.value = 0.04;
          o.connect(g).connect(ctx.destination);
          const t = ctx.currentTime + i * 0.18;
          o.start(t);
          o.stop(t + 0.1);
        }
      } catch {
        /* звук недоступен */
      }
    };

    const ll = (x: number, y: number) => kmToLatLon(city, x, y);
    const center = L.latLng(city.lat, city.lon);

    const map = L.map(mapEl.current, {
      zoomControl: false,
      zoomSnap: 0.25,
      attributionControl: true,
      minZoom: 8,
      maxZoom: 16,
    });
    L.control.zoom({ position: "bottomright" }).addTo(map);
    L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
      attribution: "© OpenStreetMap © CARTO",
      subdomains: "abcd",
    }).addTo(map);
    map.fitBounds(center.toBounds(27000), { padding: [4, 4] });

    // кольца дальности
    [3, 6, 9, 12].forEach((km) => {
      L.circle(center, {
        radius: km * 1000,
        color: "#22ff88",
        weight: 1,
        opacity: km === POST_RADIUS_KM ? 0.55 : 0.28,
        fill: false,
        dashArray: km === POST_RADIUS_KM ? undefined : "4 6",
        interactive: false,
      }).addTo(map);
    });

    // развёртка радара по центру города
    const updateSweep = () => {
      const el = sweepEl.current;
      if (!el) return;
      const p1 = map.latLngToContainerPoint(center);
      const p2 = map.latLngToContainerPoint(L.latLng(ll(12, 0)));
      const r = Math.abs(p2.x - p1.x);
      el.style.width = `${r * 2}px`;
      el.style.height = `${r * 2}px`;
      el.style.left = `${p1.x - r}px`;
      el.style.top = `${p1.y - r}px`;
    };
    map.on("move zoom resize viewreset", updateSweep);
    updateSweep();

    const ro = new ResizeObserver(() => {
      map.invalidateSize();
      updateSweep();
    });
    ro.observe(mapEl.current);

    // штаб
    L.marker(center, {
      interactive: false,
      icon: L.divIcon({
        className: "plain",
        iconSize: [0, 0],
        html: `<div class="post-marker"><div class="post-flag" style="border-color:#fbbf24;box-shadow:0 0 12px #fbbf24;border-radius:50%;transform:none"></div><div class="post-name" style="color:#fde68a">ШТАБ</div></div>`,
      }),
    }).addTo(map);

    // ---------- посты и птицы ----------
    interface Bird {
      idx: number;
      callsign: string;
      postName: string;
      post: { x: number; y: number };
      hx: number;
      hy: number;
      marker: L.Marker;
      postMarker: L.Marker;
      startAt: number;
      arrived: boolean;
      lastX: number;
      flip: boolean;
    }

    const t0 = performance.now();
    const birds: Bird[] = SCOUTS.map((s, i) => {
      const b = (POST_BEARINGS[i] * Math.PI) / 180;
      const post = { x: Math.sin(b) * POST_RADIUS_KM, y: Math.cos(b) * POST_RADIUS_KM };
      const postName = POST_NAMES[i];
      const hx = Math.cos((i / 6) * Math.PI * 2) * 0.25;
      const hy = Math.sin((i / 6) * Math.PI * 2) * 0.25;

      L.polyline([ll(0, 0), ll(post.x, post.y)], {
        color: "#4ade80",
        weight: 1,
        opacity: 0.45,
        dashArray: "2 6",
        interactive: false,
      }).addTo(map);

      const postMarker = L.marker(ll(post.x, post.y), {
        interactive: false,
        icon: L.divIcon({
          className: "plain",
          iconSize: [0, 0],
          html: `<div class="post-marker"><div class="post-flag"></div><div class="post-name">Пост ${postName}</div></div>`,
        }),
      }).addTo(map);

      const svg = renderToStaticMarkup(<Pigeon size={46} color={s.color} flap />);
      const marker = L.marker(ll(hx, hy), {
        interactive: false,
        zIndexOffset: 800,
        icon: L.divIcon({
          className: "plain bird-marker",
          iconSize: [0, 0],
          html: `<div style="position:absolute;left:-23px;top:-17px;width:46px"><div class="bird-inner">${svg}</div><div class="bird-tag">${s.callsign}</div></div>`,
        }),
      }).addTo(map);

      return {
        idx: i,
        callsign: s.callsign,
        postName,
        post,
        hx,
        hy,
        marker,
        postMarker,
        startAt: t0 + 1200 + i * 650,
        arrived: false,
        lastX: hx,
        flip: false,
      };
    });

    addLog("info", `Штаб ${city.name}: стая из 6 птиц вылетает на посты...`);

    // ---------- дроны ----------
    interface Drone {
      n: number;
      x: number;
      y: number;
      vx: number;
      vy: number;
      sx: number;
      sy: number;
      marker: L.Marker;
      line: L.Polyline;
      reported: Set<number>;
      warned: boolean;
      dead: boolean;
    }
    const drones: Drone[] = [];
    let droneCounter = 0;
    let detectedCount = 0;
    let destroyedCount = 0;
    let arrivedCount = 0;
    let allArrivedAt = 0;
    let nextSpawn = Infinity;
    let nextChat = Infinity;

    const flashPost = (b: Bird) => {
      const el = b.postMarker.getElement()?.firstElementChild as HTMLElement | null;
      if (!el) return;
      el.classList.remove("alert");
      void el.offsetWidth;
      el.classList.add("alert");
      setTimeout(() => el.classList.remove("alert"), 3600);
    };

    const spawnDrone = () => {
      const ang = Math.random() * Math.PI * 2;
      const dist = 15;
      const sx = Math.sin(ang) * dist;
      const sy = Math.cos(ang) * dist;
      const tx = (Math.random() - 0.5) * 3;
      const ty = (Math.random() - 0.5) * 3;
      const d = Math.hypot(tx - sx, ty - sy);
      const speed = 0.32 + Math.random() * 0.14;
      const n = ++droneCounter;
      const icon = L.divIcon({
        className: "plain",
        iconSize: [0, 0],
        html: `<div style="position:absolute;left:-15px;top:-15px;width:30px"><div class="drone-inner"><svg viewBox="0 0 40 40" width="30" height="30"><polygon points="20,2 27,32 20,27 13,32" fill="#ff3b3b" stroke="#fff" stroke-width="1.2"/><rect x="6" y="26" width="28" height="3" rx="1.5" fill="#ff3b3b" stroke="#fff" stroke-width="0.8"/></svg></div><div class="drone-tag">БПЛА-${n}</div></div>`,
      });
      const pos = ll(sx, sy);
      const marker = L.marker(pos, { icon, interactive: false, zIndexOffset: 1500 }).addTo(map);
      const line = L.polyline([pos, pos], { color: "#ff3b3b", weight: 1.5, opacity: 0.8, dashArray: "3 5", interactive: false }).addTo(map);
      drones.push({
        n,
        x: sx,
        y: sy,
        vx: ((tx - sx) / d) * speed,
        vy: ((ty - sy) / d) * speed,
        sx,
        sy,
        marker,
        line,
        reported: new Set(),
        warned: false,
        dead: false,
      });
      setActive(drones.filter((x) => !x.dead).length);
    };

    const explode = (x: number, y: number) => {
      const m = L.marker(ll(x, y), {
        interactive: false,
        icon: L.divIcon({ className: "plain", iconSize: [0, 0], html: `<div class="hit-ring"></div>` }),
      }).addTo(map);
      setTimeout(() => m.remove(), 1100);
    };

    // ---------- главный цикл ----------
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;

      // птицы
      for (const b of birds) {
        let x: number;
        let y: number;
        if (now < b.startAt) {
          x = b.hx + Math.sin(now / 400 + b.idx) * 0.03;
          y = b.hy;
        } else {
          const u = clamp((now - b.startAt) / FLIGHT_MS, 0, 1);
          if (u < 1) {
            const e = u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2;
            const wob = Math.sin(u * Math.PI) * 0.35 * Math.sin(u * 8 + b.idx);
            const len = Math.hypot(b.post.x, b.post.y) || 1;
            x = b.hx + (b.post.x - b.hx) * e + (-b.post.y / len) * wob;
            y = b.hy + (b.post.y - b.hy) * e + (b.post.x / len) * wob;
          } else {
            if (!b.arrived) {
              b.arrived = true;
              arrivedCount++;
              setBirdsOnPost(arrivedCount);
              addLog("ok", `Голубь «${b.callsign}» занял пост «${b.postName}». Наблюдение ведётся.`);
              if (arrivedCount === birds.length) {
                allArrivedAt = now;
                nextSpawn = now + 3500;
                nextChat = now + 9000;
                addLog("info", "Все 6 птиц на постах. Воздушное пространство под контролем.");
              }
            }
            const a = now / 1700 + b.idx * 1.3;
            x = b.post.x + Math.cos(a) * 0.35;
            y = b.post.y + Math.sin(a) * 0.35;
          }
        }
        b.marker.setLatLng(ll(x, y));
        const dx = x - b.lastX;
        if (Math.abs(dx) > 1e-4) b.flip = dx < 0;
        b.lastX = x;
        const inner = b.marker.getElement()?.querySelector(".bird-inner") as HTMLElement | null;
        if (inner) inner.style.transform = b.flip ? "scaleX(-1)" : "";
      }

      // дроны
      for (const d of drones) {
        if (d.dead) continue;
        d.x += d.vx * dt;
        d.y += d.vy * dt;
        const pos = ll(d.x, d.y);
        d.marker.setLatLng(pos);
        d.line.setLatLngs([ll(d.sx, d.sy), pos]);
        const inner = d.marker.getElement()?.querySelector(".drone-inner") as HTMLElement | null;
        if (inner) inner.style.transform = `rotate(${(Math.atan2(d.vx, d.vy) * 180) / Math.PI}deg)`;

        const distC = Math.hypot(d.x, d.y);
        const az = Math.round(((Math.atan2(d.x, d.y) * 180) / Math.PI + 360) % 360);
        const coords = `${pos[0].toFixed(3)}°N, ${pos[1].toFixed(3)}°E`;

        // обнаружение птицами
        for (const b of birds) {
          if (!b.arrived || d.reported.has(b.idx)) continue;
          if (d.reported.size > 0) continue; // первое обнаружение — одним постом
          if (Math.hypot(d.x - b.post.x, d.y - b.post.y) < DETECT_KM) {
            d.reported.add(b.idx);
            detectedCount++;
            setDetected(detectedCount);
            flashPost(b);
            beep(880, 2);
            addLog(
              "alert",
              `🚨 «${b.callsign}» (пост «${b.postName}»): вижу БПЛА-убийцу №${d.n}! Азимут ${az}°, до центра ${distC.toFixed(1)} км, курс на город. Координаты ${coords}`
            );
          }
        }

        // предупреждение о приближении
        if (d.reported.size > 0 && !d.warned && distC < 7.5) {
          d.warned = true;
          let nearest = birds[0];
          let nd = Infinity;
          for (const b of birds) {
            const dd = Math.hypot(d.x - b.post.x, d.y - b.post.y);
            if (b.arrived && dd < nd) {
              nd = dd;
              nearest = b;
            }
          }
          flashPost(nearest);
          beep(1100, 3);
          addLog("alert", `⚠️ «${nearest.callsign}»: БПЛА №${d.n} входит в зону города! Дистанция до центра ${distC.toFixed(1)} км. Передаю на ПВО.`);
        }

        // уничтожение
        if (distC < KILL_KM) {
          d.dead = true;
          destroyedCount++;
          setDestroyed(destroyedCount);
          explode(d.x, d.y);
          beep(300, 1);
          addLog("ok", `✅ БПЛА №${d.n} уничтожен средствами ПВО над окраиной. Угроза устранена.`);
          setTimeout(() => {
            d.marker.remove();
            d.line.remove();
          }, 600);
          setActive(drones.filter((x) => !x.dead).length);
        }
      }

      // новые дроны
      if (allArrivedAt && now > nextSpawn) {
        if (drones.filter((x) => !x.dead).length < 3) spawnDrone();
        nextSpawn = now + 7000 + Math.random() * 9000;
      }

      // фоновые доклады
      if (allArrivedAt && now > nextChat) {
        const b = birds[Math.floor(Math.random() * birds.length)];
        const msgs = [
          "на посту спокойно, небо чистое.",
          "ветер усиливается, видимость отличная.",
          "наблюдаю, подозрительных целей нет.",
          "связь устойчивая, продолжаю дозор.",
        ];
        addLog("info", `«${b.callsign}» (${b.postName}): ${msgs[Math.floor(Math.random() * msgs.length)]}`);
        nextChat = now + 8000 + Math.random() * 8000;
      }

      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      map.remove();
    };
  }, [city]);

  return (
    <div className="flex h-full w-full flex-col bg-[#03120a] md:flex-row">
      {/* карта */}
      <div className="relative min-h-0 flex-1">
        <div ref={mapEl} className="radar-map absolute inset-0 vignette scanlines" />
        <div className="pointer-events-none absolute inset-0 z-[450] overflow-hidden">
          <div ref={sweepEl} className="radar-sweep absolute" />
        </div>

        {/* шапка */}
        <div className="absolute inset-x-0 top-0 z-[600] flex items-start justify-between gap-2 bg-gradient-to-b from-black/85 to-transparent px-3 pt-3 pb-8">
          <button
            onClick={onBack}
            className="rounded-lg border border-emerald-500/40 bg-black/70 px-3 py-1.5 text-sm text-emerald-200 active:scale-95"
          >
            ← К радару
          </button>
          <div className="text-right">
            <p className="font-mono-r text-xs tracking-[0.25em] text-emerald-400">РАДАР · {city.name.toUpperCase()}</p>
            <p className="text-[11px] text-emerald-200/70">{city.region} · {city.lat.toFixed(3)}°N {city.lon.toFixed(3)}°E</p>
          </div>
        </div>

        {active > 0 && (
          <div className="blink pointer-events-none absolute left-1/2 top-16 z-[650] -translate-x-1/2 whitespace-nowrap rounded-lg border border-red-500 bg-red-950/85 px-4 py-1.5 font-mono-r text-sm font-bold text-red-300 shadow-[0_0_20px_rgba(255,0,0,0.5)]">
            ⚠ ВОЗДУШНАЯ ТРЕВОГА · целей: {active}
          </div>
        )}
      </div>

      {/* панель докладов */}
      <aside className="flex h-[40%] min-h-0 flex-col border-t border-emerald-500/30 bg-[#04100a] md:h-full md:w-96 md:border-l md:border-t-0">
        <div className="grid grid-cols-3 gap-2 border-b border-emerald-900 p-2 text-center">
          <div className="rounded-lg bg-emerald-950/70 p-1.5">
            <p className="font-mono-r text-lg font-bold text-emerald-300">{birdsOnPost}/6</p>
            <p className="text-[10px] uppercase text-emerald-200/60">птиц на постах</p>
          </div>
          <div className="rounded-lg bg-red-950/60 p-1.5">
            <p className="font-mono-r text-lg font-bold text-red-400">{detected}</p>
            <p className="text-[10px] uppercase text-red-200/60">обнаружено БПЛА</p>
          </div>
          <div className="rounded-lg bg-amber-950/50 p-1.5">
            <p className="font-mono-r text-lg font-bold text-amber-300">{destroyed}</p>
            <p className="text-[10px] uppercase text-amber-200/60">уничтожено</p>
          </div>
        </div>
        <div className="flex items-center justify-between px-3 py-1.5">
          <span className="font-mono-r text-[11px] tracking-widest text-emerald-400">ДОКЛАДЫ ПТИЦ</span>
          <button
            onClick={() => setMuted((m) => !m)}
            className="rounded border border-emerald-700/60 px-2 py-0.5 text-xs text-emerald-200 active:scale-95"
          >
            {muted ? "🔇 звук выкл" : "🔊 звук вкл"}
          </button>
        </div>
        <div className="log-scroll min-h-0 flex-1 space-y-1.5 overflow-y-auto px-2 pb-3">
          {log.map((e) => (
            <div
              key={e.id}
              className={
                "slide-in rounded-md border-l-4 px-2.5 py-1.5 text-[13px] leading-snug " +
                (e.level === "alert"
                  ? "border-red-500 bg-red-950/60 text-red-100"
                  : e.level === "ok"
                  ? "border-lime-400 bg-emerald-950/60 text-lime-100"
                  : "border-emerald-700 bg-emerald-950/30 text-emerald-100/80")
              }
            >
              <span className="mr-2 font-mono-r text-[10px] opacity-60">{e.time}</span>
              {e.text}
            </div>
          ))}
        </div>
      </aside>
    </div>
  );
}
