import { useState } from "react";
import { SCOUTS } from "../data/cities";
import { Pigeon } from "./Pigeon";

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex items-center gap-2 text-[10px] font-mono-r text-emerald-200/70">
      <span className="w-12 uppercase">{label}</span>
      <div className="h-1.5 flex-1 rounded bg-black/40 overflow-hidden">
        <div className="h-full bg-gradient-to-r from-emerald-500 to-lime-300" style={{ width: `${value}%` }} />
      </div>
      <span className="w-6 text-right">{value}</span>
    </div>
  );
}

export function TeamScreen({ onRadar }: { onRadar: () => void }) {
  const [phase, setPhase] = useState<"idle" | "flying" | "sent">("idle");

  const launch = () => {
    setPhase("flying");
    setTimeout(() => setPhase("sent"), 2000);
  };

  return (
    <div className="relative h-full w-full overflow-y-auto bg-gradient-to-b from-[#06150f] to-[#0b2418]">
      <div className="mx-auto max-w-5xl px-4 py-6 pb-32">
        <header className="text-center pop-in">
          <p className="font-mono-r text-xs tracking-[0.35em] text-emerald-400/80">ОТДЕЛ ВОЗДУШНОЙ РАЗВЕДКИ</p>
          <h1 className="mt-2 text-2xl sm:text-3xl font-extrabold text-emerald-100">Команда голубей-разведчиков</h1>
          <p className="mt-1 text-sm text-emerald-200/60">6 птиц · готовность 100% · погода: ясно, ветер 3 м/с</p>
        </header>

        <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {SCOUTS.map((s, i) => (
            <div
              key={s.id}
              className="pop-in relative overflow-hidden rounded-2xl border border-emerald-500/25 bg-emerald-950/50 p-4 backdrop-blur"
              style={{ animationDelay: `${i * 90}ms` }}
            >
              <div className="flex items-center gap-3">
                <div className={phase !== "idle" ? "fly-away" : ""} style={{ animationDelay: `${i * 120}ms` }}>
                  <Pigeon size={84} color={s.color} flap={phase !== "idle"} />
                </div>
                <div className="min-w-0">
                  <p className="font-mono-r text-[10px] text-emerald-400/80">ПТИЦА №{String(s.id).padStart(2, "0")}</p>
                  <h3 className="text-lg font-bold text-emerald-50 leading-tight">«{s.callsign}»</h3>
                  <p className="text-xs text-emerald-200/70">{s.role}</p>
                </div>
              </div>
              <div className="mt-3 space-y-1">
                <Stat label="скорость" value={s.speed} />
                <Stat label="зрение" value={s.vision} />
                <Stat label="выносл." value={s.stamina} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* нижняя панель */}
      <div className="fixed inset-x-0 bottom-0 z-20 border-t border-emerald-500/30 bg-[#04100a]/95 backdrop-blur px-4 py-4">
        <div className="mx-auto max-w-xl flex flex-col sm:flex-row items-center justify-center gap-3">
          {phase === "sent" ? (
            <>
              <p className="pop-in text-center text-lg font-bold text-lime-300">✅ Все птицы отправлены на посты!</p>
              <button
                onClick={onRadar}
                className="pop-in w-full sm:w-auto rounded-xl bg-gradient-to-r from-emerald-400 to-lime-300 px-6 py-3 font-extrabold text-emerald-950 shadow-[0_0_24px_rgba(74,222,128,0.5)] active:scale-95 transition"
              >
                📡 Посмотреть радар
              </button>
            </>
          ) : (
            <button
              onClick={launch}
              disabled={phase === "flying"}
              className="w-full sm:w-auto rounded-xl bg-gradient-to-r from-emerald-400 to-lime-300 px-8 py-3.5 font-extrabold text-emerald-950 shadow-[0_0_24px_rgba(74,222,128,0.5)] active:scale-95 transition disabled:opacity-60"
            >
              {phase === "flying" ? "Птицы взлетают..." : "🕊️ Запустить птиц на посты"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
