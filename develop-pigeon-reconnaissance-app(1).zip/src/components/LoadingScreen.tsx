import { useEffect, useState } from "react";
import { Pigeon } from "./Pigeon";

const STEPS = [
  "Кормим голубей...",
  "Проверяем кольца и маркировку...",
  "Настраиваем радиосвязь...",
  "Загружаем карты городов...",
  "Стая готова к вылету",
];

export function LoadingScreen({ onDone }: { onDone: () => void }) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const start = performance.now();
    const total = 4200;
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / total);
      setProgress(p);
      if (p < 1) raf = requestAnimationFrame(tick);
      else setTimeout(onDone, 400);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [onDone]);

  const step = Math.min(STEPS.length - 1, Math.floor(progress * STEPS.length));

  return (
    <div className="relative h-full w-full overflow-hidden bg-gradient-to-b from-[#0b2a3a] via-[#123b4a] to-[#1d5b55] flex flex-col items-center justify-center px-6">
      {/* облака */}
      {[10, 28, 62, 80].map((top, i) => (
        <div
          key={i}
          className="cloud absolute rounded-full bg-white/10 blur-md"
          style={{ top: `${top}%`, width: 160 + i * 40, height: 40 + i * 8, animationDuration: `${22 + i * 7}s`, animationDelay: `-${i * 6}s` }}
        />
      ))}

      <div className="bob relative z-10">
        <div className="absolute inset-0 -z-10 rounded-full bg-emerald-300/20 blur-3xl scale-150" />
        <Pigeon size={230} color="#a9b6cc" />
      </div>

      <h1 className="relative z-10 mt-8 text-3xl sm:text-4xl font-extrabold tracking-wider text-emerald-100 text-center">
        ГОЛУБИНЫЙ ДОЗОР
      </h1>
      <p className="relative z-10 mt-1 text-sm text-emerald-200/70 tracking-[0.3em] uppercase">воздушная разведка</p>

      <div className="relative z-10 mt-10 w-full max-w-xs">
        <div className="h-2.5 w-full overflow-hidden rounded-full bg-black/40 border border-emerald-400/30">
          <div
            className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-lime-300"
            style={{ width: `${progress * 100}%` }}
          />
        </div>
        <div className="mt-3 flex justify-between font-mono-r text-xs text-emerald-100/80">
          <span>{STEPS[step]}</span>
          <span>{Math.round(progress * 100)}%</span>
        </div>
      </div>
    </div>
  );
}
